/* ------------- app.js ------------- */
document.addEventListener('DOMContentLoaded', () => {

  const {
    leadForm, viewFichesButton, fichesModal, closeFichesModal,
    importExportButton, importExportModal, closeImportExportModal,
    formSteps, formSidebarItems, nextButtons, nextButtonsSimple,
    cancelButton, leadTypeButtons, leadTypeInput,
    decisionButtons, sentimentButtons, decideurInput,
    interetClientInput, interetIIInput, nomDecideurGroup, nomDecideurInput,
    saveButton, saveButtonQualification, saveButtonNotes,
    clearInputButtons, modalTabs, modalTabContents,
    confirmDeleteModal, closeDeleteModalButton, cancelDeleteButton,
    confirmDeleteButton,
    fichesGridAll, fichesGridIncomplete, emptyFiches, emptyIncompleteFiches,
    exportAllFichesButton, exportSelectedFichesButton, exportAllButton,
    importButton, importFileInput, offlineIndicator,
    prenomInput, nomInput, emailInput,
    generateId, formatDate, showToast,
    downloadFile, parseCSV, updateOnlineStatus,
    initDB, getAllLeadsFromDB, saveLeadToDB, deleteLeadFromDB
  } = window;

  let {
    currentStep, leadsData, currentLeadId, isEditing,
    selectedLeads, leadToDelete, visitedSteps
  } = window;

  /* ---------- 1. Initialisation IndexedDB et chargement des données ---------- */
  initDB().then(() => {
    return getAllLeadsFromDB();
  }).then(savedLeadsFromDB => {
    leadsData = savedLeadsFromDB;
    console.log('Leads loaded from IndexedDB:', leadsData);
    // Optionally, render fiches or update UI if needed immediately after loading
    // For now, we assume initForm and other initial setup will handle UI updates.
  }).catch(error => {
    console.error('Error initializing DB or fetching leads:', error);
    showToast('Erreur', 'Impossible de charger les fiches depuis IndexedDB.', 'error');
    leadsData = []; // Start with an empty array if DB fails
  }).finally(() => {
    /* ---------- 2. État online/offline ---------- */
    window.addEventListener('online', updateOnlineStatus);
    window.addEventListener('offline', updateOnlineStatus);
    updateOnlineStatus();

    /* ---------- 3. Initialisation du formulaire ---------- */
    initForm(); // Ensure initForm is called after leadsData might be populated
  });

  /* === Fonctions === */

  function initForm() {
    currentLeadId = generateId();
    document.getElementById('leadId').value = currentLeadId;
    leadForm.reset();

    nomDecideurGroup.classList.add('hidden');
    leadTypeButtons.forEach(b => b.classList.remove('selected'));
    leadTypeInput.value = '';
    decisionButtons.forEach(b => b.classList.remove('selected'));
    decideurInput.value = '';
    sentimentButtons.forEach(b => b.classList.remove('selected'));
    interetClientInput.value = '';
    interetIIInput.value = '';

    currentStep = 0;
    visitedSteps = [0];
    showStep(currentStep);
    isEditing = false;
    updateSidebarItems();
  }

  /* ---------- Navigation étapes ---------- */
  function showStep(idx) {
    formSteps.forEach((step, i) => step.classList.toggle('hidden', i !== idx));
    formSidebarItems.forEach((it, i) => it.classList.toggle('active', i === idx));
    if (!visitedSteps.includes(idx)) visitedSteps.push(idx);
    updateSidebarItems();
  }

  function updateSidebarItems() {
    formSidebarItems.forEach((it, i) => it.classList.toggle('visited', visitedSteps.includes(i)));
  }

  function validateStep(idx) {
    const step = formSteps[idx],
      required = step.querySelectorAll('[required]');
    for (let input of required) {
      if (!input.value.trim()) {
        showToast('Champ requis', 'Veuillez remplir tous les champs obligatoires.', 'error');
        input.focus(); return false;
      }
      if (input.type === 'email' &&
        !/^\S+@\S+\.\S+$/.test(input.value.trim())) {
        showToast('Format invalide', "Veuillez entrer une adresse courriel valide.", "error");
        input.focus(); return false;
      }
    }
    return true;
  }

  function goToNextStep() {
    if (currentStep < formSteps.length - 1) { currentStep++; showStep(currentStep); }
  }

  /* ---------- Listeners principaux ---------- */
  nextButtons.forEach(btn => btn.addEventListener('click', () => {
    if (validateStep(currentStep)) goToNextStep();
  }));
  nextButtonsSimple.forEach(btn => btn.addEventListener('click', goToNextStep));

  formSidebarItems.forEach((item, idx) => item.addEventListener('click', () => {
    if (visitedSteps.includes(1) || idx <= 1) { currentStep = idx; showStep(currentStep); }
    else showToast('Navigation',
      'Veuillez d\'abord remplir le type de lead et les informations de contact.',
      'warning');
  }));

  cancelButton.addEventListener('click', () => {
    const hasData = Array.from(leadForm.elements).some(el => {
      if (el.type === 'radio' || el.type === 'checkbox') return el.checked;
      if (['hidden', 'submit', 'button'].includes(el.type)) return false;
      return el.value.trim() !== '';
    });
    if (hasData && !isEditing) {
      if (confirm('Êtes-vous sûr de vouloir annuler ? Les données saisies seront perdues.'))
        initForm();
    } else initForm();
  });

  /* ---------- Sélection type de lead ---------- */
  leadTypeButtons.forEach(btn => btn.addEventListener('click', () => {
    leadTypeButtons.forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
    leadTypeInput.value = btn.dataset.value;
    setTimeout(goToNextStep, 300);
  }));

  /* ---------- Nettoyage champ texte ---------- */
  clearInputButtons.forEach(btn => btn.addEventListener('click', () => {
    const id = btn.dataset.for, input = document.getElementById(id);
    if (input) { input.value = ''; input.focus(); }
  }));

  /* ---------- Auto‑remplissage email ---------- */
  function updateEmail() {
    const p = prenomInput.value.trim().toLowerCase(),
      n = nomInput.value.trim().toLowerCase();
    if (p && n && !emailInput.value) {
      const np = p.normalize("NFD").replace(/[\u0300-\u036f]/g, ""),
        nn = n.normalize("NFD").replace(/[\u0300-\u036f]/g, "");
      emailInput.value = `${np}.${nn}@`;
    }
  }
  prenomInput.addEventListener('blur', updateEmail);
  nomInput.addEventListener('blur', updateEmail);

  /* ---------- Décideur Oui/Non ---------- */
  decisionButtons.forEach(btn => btn.addEventListener('click', () => {
    decideurInput.value = btn.dataset.value;
    btn.parentElement.querySelectorAll('.decision-button')
      .forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');

    nomDecideurGroup.classList.toggle('hidden', btn.dataset.value !== 'Non');
    if (btn.dataset.value === 'Oui') nomDecideurInput.value = '';
  }));

  /* ---------- Sentiments ---------- */
  sentimentButtons.forEach(btn => btn.addEventListener('click', () => {
    const group = btn.parentElement.dataset.group,
      value = btn.dataset.value;
    if (group === 'interetClient') interetClientInput.value = value;
    else if (group === 'interetII') interetIIInput.value = value;
    btn.parentElement.querySelectorAll('.sentiment-button')
      .forEach(b => b.classList.remove('selected'));
    btn.classList.add('selected');
  }));

  /* ---------- Tabs du modal ---------- */
  modalTabs.forEach(tab => tab.addEventListener('click', () => {
    const id = tab.dataset.tab;
    modalTabs.forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    modalTabContents.forEach(c => c.classList.toggle('active', c.id === id));
  }));

  /* ---------- Ouverture/fermeture des modaux ---------- */
  viewFichesButton.addEventListener('click', () => {
    fichesModal.classList.remove('hidden'); renderFiches();
  });
  closeFichesModal.addEventListener('click', () => fichesModal.classList.add('hidden'));

  importExportButton.addEventListener('click', () => importExportModal.classList.remove('hidden'));
  closeImportExportModal.addEventListener('click', () => importExportModal.classList.add('hidden'));

  /* ---------- Sauvegarde ---------- */
  saveButton.addEventListener('click', saveLead);
  saveButtonQualification.addEventListener('click', saveLead);
  saveButtonNotes.addEventListener('click', saveLead);

  async function saveLead() {
    if (!emailInput.value.trim()) {
      showToast('Champ requis', 'Veuillez remplir le champ email.', 'error');
      if (currentStep !== 1) { currentStep = 1; showStep(currentStep); }
      emailInput.focus(); return;
    }
    const data = Object.fromEntries(new FormData(leadForm).entries());
    data.timestamp = new Date().toISOString();
    data.isComplete = !!data.email.trim();
    if (data.decideur === 'Oui') data.nomDecideur = '';

    try {
      await saveLeadToDB(data);
      // After successful save, update the local leadsData array
      const idx = leadsData.findIndex(l => l.leadId === data.leadId);
      if (idx !== -1) {
        leadsData[idx] = data; // Update existing
      } else {
        leadsData.push(data); // Add new
      }
      showToast('Succès', isEditing ? 'Fiche mise à jour avec succès !' : 'Nouvelle fiche ajoutée !');
      // saveLeadsToLocalStorage(leadsData); // Removed
      initForm();
    } catch (error) {
      console.error('Failed to save lead to DB:', error);
      showToast('Erreur', 'La sauvegarde de la fiche a échoué.', 'error');
    }
  }

  // Render fiches in modal
  function renderFiches(searchTerm = '') {
    // Filter fiches if search term provided
    let filteredFiches = leadsData;
    if (searchTerm) {
      const term = searchTerm.toLowerCase();
      filteredFiches = leadsData.filter(lead => {
        return (
          (lead.prenom && lead.prenom.toLowerCase().includes(term)) ||
          (lead.nom && lead.nom.toLowerCase().includes(term)) ||
          (lead.email && lead.email.toLowerCase().includes(term)) ||
          (lead.entreprise && lead.entreprise.toLowerCase().includes(term))
        );
      });
    }

    // Sort by timestamp (newest first)
    filteredFiches.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

    // Separate complete and incomplete fiches
    const completeFiches = filteredFiches.filter(lead => lead.isComplete);
    const incompleteFiches = filteredFiches.filter(lead => !lead.isComplete);

    // Render all fiches
    if (filteredFiches.length === 0) {
      fichesGridAll.innerHTML = '';
      emptyFiches.classList.remove('hidden');
    } else {
      emptyFiches.classList.add('hidden');

      let html = '';
      filteredFiches.forEach(lead => {
        const name = `${lead.prenom || ''} ${lead.nom || ''}`.trim() || 'Sans nom';
        const email = lead.email || 'Email non renseigné';
        const type = lead.leadType || 'Type non spécifié';
        const entreprise = lead.entreprise || 'Entreprise non spécifiée';
        const date = new Date(lead.timestamp).toLocaleDateString();
        const isIncomplete = !lead.isComplete;

        html += `
                        <div class="fiche-card ${isIncomplete ? 'incomplete' : ''}">
                            <input type="checkbox" class="fiche-checkbox" data-id="${lead.leadId}">
                            <div class="fiche-header">
                                <div class="fiche-title">${name}</div>
                                <div class="fiche-type">${type}</div>
                            </div>
                            <div class="fiche-info"><strong>Email:</strong> ${email}</div>
                            <div class="fiche-info"><strong>Entreprise:</strong> ${entreprise}</div>
                            <div class="fiche-info"><strong>Date:</strong> ${date}</div>
                            <div class="fiche-actions">
                                <button type="button" class="fiche-action edit-fiche" data-id="${lead.leadId}" title="Modifier">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                    </svg>
                                </button>
                                <button type="button" class="fiche-action delete-fiche" data-id="${lead.leadId}" title="Supprimer">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <polyline points="3 6 5 6 21 6"></polyline>
                                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                        `;
      });

      fichesGridAll.innerHTML = html;

      // Add event listeners
      document.querySelectorAll('.edit-fiche').forEach(button => {
        button.addEventListener('click', (e) => {
          const leadId = e.currentTarget.getAttribute('data-id');
          editLead(leadId);
          fichesModal.classList.add('hidden');
        });
      });

      document.querySelectorAll('.delete-fiche').forEach(button => {
        button.addEventListener('click', (e) => {
          const leadId = e.currentTarget.getAttribute('data-id');
          leadToDelete = leadId;
          confirmDeleteModal.classList.remove('hidden');
        });
      });

      document.querySelectorAll('.fiche-card').forEach(card => {
        card.addEventListener('click', (e) => {
          // Only trigger if not clicking on a button or checkbox
          if (!e.target.closest('.fiche-action') && !e.target.closest('.fiche-checkbox')) {
            const leadId = card.querySelector('.fiche-action').getAttribute('data-id');
            editLead(leadId);
            fichesModal.classList.add('hidden');
          }
        });
      });

      // Handle checkboxes for selection
      document.querySelectorAll('.fiche-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', () => {
          const leadId = checkbox.getAttribute('data-id');
          if (checkbox.checked) {
            if (!selectedLeads.includes(leadId)) {
              selectedLeads.push(leadId);
            }
          } else {
            selectedLeads = selectedLeads.filter(id => id !== leadId);
          }
          updateExportSelectedButton();
        });
      });
    }

    // Render incomplete fiches
    if (incompleteFiches.length === 0) {
      fichesGridIncomplete.innerHTML = '';
      emptyIncompleteFiches.classList.remove('hidden');
    } else {
      emptyIncompleteFiches.classList.add('hidden');

      let html = '';
      incompleteFiches.forEach(lead => {
        const name = `${lead.prenom || ''} ${lead.nom || ''}`.trim() || 'Sans nom';
        const email = lead.email || 'Email non renseigné';
        const type = lead.leadType || 'Type non spécifié';
        const date = new Date(lead.timestamp).toLocaleDateString();

        // Calculate completion percentage
        const totalFields = 8; // Adjust based on your required fields
        let filledFields = 0;
        if (lead.leadType) filledFields++;
        if (lead.prenom) filledFields++;
        if (lead.nom) filledFields++;
        if (lead.email) filledFields++;
        if (lead.entreprise) filledFields++;
        if (lead.decideur) filledFields++;
        if (lead.interetClient) filledFields++;
        if (lead.interetII) filledFields++;

        const completionPercentage = Math.round((filledFields / totalFields) * 100);

        html += `
                        <div class="fiche-card incomplete">
                            <input type="checkbox" class="fiche-checkbox" data-id="${lead.leadId}">
                            <div class="fiche-header">
                                <div class="fiche-title">${name}</div>
                                <div class="fiche-type">${type}</div>
                            </div>
                            <div class="fiche-info"><strong>Email:</strong> ${email}</div>
                            <div class="fiche-info"><strong>Date:</strong> ${date}</div>
                            <div class="fiche-info">
                                <strong>Progression:</strong> ${completionPercentage}%
                                <div class="progress-container">
                                    <div class="progress-bar" style="width: ${completionPercentage}%"></div>
                                </div>
                            </div>
                            <div class="fiche-actions">
                                <button type="button" class="fiche-action edit-fiche" data-id="${lead.leadId}" title="Modifier">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"></path>
                                        <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"></path>
                                    </svg>
                                </button>
                                <button type="button" class="fiche-action delete-fiche" data-id="${lead.leadId}" title="Supprimer">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                        <polyline points="3 6 5 6 21 6"></polyline>
                                        <path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path>
                                    </svg>
                                </button>
                            </div>
                        </div>
                        `;
      });

      fichesGridIncomplete.innerHTML = html;

      // Add event listeners
      document.querySelectorAll('.edit-fiche').forEach(button => {
        button.addEventListener('click', (e) => {
          const leadId = e.currentTarget.getAttribute('data-id');
          editLead(leadId);
          fichesModal.classList.add('hidden');
        });
      });

      document.querySelectorAll('.delete-fiche').forEach(button => {
        button.addEventListener('click', (e) => {
          const leadId = e.currentTarget.getAttribute('data-id');
          leadToDelete = leadId;
          confirmDeleteModal.classList.remove('hidden');
        });
      });

      document.querySelectorAll('.fiche-card').forEach(card => {
        card.addEventListener('click', (e) => {
          // Only trigger if not clicking on a button or checkbox
          if (!e.target.closest('.fiche-action') && !e.target.closest('.fiche-checkbox')) {
            const leadId = card.querySelector('.fiche-action').getAttribute('data-id');
            editLead(leadId);
            fichesModal.classList.add('hidden');
          }
        });
      });

      // Handle checkboxes for selection
      document.querySelectorAll('.fiche-checkbox').forEach(checkbox => {
        checkbox.addEventListener('change', () => {
          const leadId = checkbox.getAttribute('data-id');
          if (checkbox.checked) {
            if (!selectedLeads.includes(leadId)) {
              selectedLeads.push(leadId);
            }
          } else {
            selectedLeads = selectedLeads.filter(id => id !== leadId);
          }
          updateExportSelectedButton();
        });
      });
    }

    updateExportSelectedButton();
  }

  // Edit lead
  function editLead(leadId) {
    const lead = leadsData.find(l => l.leadId === leadId);
    if (!lead) return;

    // Fill form with lead data
    document.getElementById('leadId').value = lead.leadId;

    // Set lead type
    if (lead.leadType) {
      leadTypeInput.value = lead.leadType;
      leadTypeButtons.forEach(button => {
        const value = button.getAttribute('data-value');
        button.classList.toggle('selected', value === lead.leadType);
      });
    }

    // Fill contact info
    document.getElementById('prenom').value = lead.prenom || '';
    document.getElementById('nom').value = lead.nom || '';
    document.getElementById('email').value = lead.email || '';
    document.getElementById('telephone').value = lead.telephone || '';

    // Fill company info
    document.getElementById('entreprise').value = lead.entreprise || '';
    document.getElementById('intitule').value = lead.intitule || '';
    document.getElementById('secteur').value = lead.secteur || '';

    // Fill qualification info
    if (lead.decideur) {
      const selectedDecisionButton = document.querySelector(`.decision-button[data-value="${lead.decideur}"]`);
      if (selectedDecisionButton) {
        selectedDecisionButton.click(); // Simulate click to apply styles and logic
      } else { // Fallback for old data if necessary, or clear if not matching
        decisionButtons.forEach(btn => btn.classList.remove('selected'));
        decideurInput.value = '';
        nomDecideurGroup.classList.add('hidden');
      }
      // nomDecideurInput value is handled by the click logic if 'Non'
    } else {
      decisionButtons.forEach(btn => btn.classList.remove('selected'));
      decideurInput.value = '';
      nomDecideurGroup.classList.add('hidden');
    }

    if (lead.interetClient) {
      const selectedClientButton = document.querySelector(`.sentiment-buttons[data-group="interetClient"] .sentiment-button[data-value="${lead.interetClient}"]`);
      if (selectedClientButton) {
        selectedClientButton.click();
      } else {
        document.querySelectorAll('.sentiment-buttons[data-group="interetClient"] .sentiment-button').forEach(btn => btn.classList.remove('selected'));
        interetClientInput.value = '';
      }
    }
    else {
      document.querySelectorAll('.sentiment-buttons[data-group="interetClient"] .sentiment-button').forEach(btn => btn.classList.remove('selected'));
      interetClientInput.value = '';
    }

    if (lead.interetII) {
      const selectedIIButton = document.querySelector(`.sentiment-buttons[data-group="interetII"] .sentiment-button[data-value="${lead.interetII}"]`);
      if (selectedIIButton) {
        selectedIIButton.click();
      } else {
        document.querySelectorAll('.sentiment-buttons[data-group="interetII"] .sentiment-button').forEach(btn => btn.classList.remove('selected'));
        interetIIInput.value = '';
      }
    } else {
      document.querySelectorAll('.sentiment-buttons[data-group="interetII"] .sentiment-button').forEach(btn => btn.classList.remove('selected'));
      interetIIInput.value = '';
    }

    // Fill notes
    document.getElementById('notes').value = lead.notes || '';
    document.getElementById('actions').value = lead.actions || '';

    // Set editing state
    isEditing = true;
    currentLeadId = leadId;

    // Reset visited steps and mark all as visited for editing
    visitedSteps = [0, 1, 2, 3, 4];

    // Go to first step
    currentStep = 0;
    showStep(currentStep);

    // Update sidebar items
    updateSidebarItems();
  }

  exportAllFichesButton.addEventListener('click', exportAllLeads);
  exportAllButton.addEventListener('click', exportAllLeads);

  function exportAllLeads() {
    if (leadsData.length === 0) {
      showToast('Information', "Aucune fiche à exporter.", 'warning');
      return;
    }

    const format = document.querySelector('input[name="exportFormat"]:checked')?.value || 'csv';

    if (format === 'csv') {
      exportToCSV(leadsData);
    } else if (format === 'json') {
      exportToJSON(leadsData);
    }
  }

  exportSelectedFichesButton.addEventListener('click', () => {
    if (selectedLeads.length === 0) {
      showToast('Information', "Aucune fiche sélectionnée.", 'warning');
      return;
    }

    const selectedLeadsData = leadsData.filter(lead => selectedLeads.includes(lead.leadId));
    exportToCSV(selectedLeadsData);
  });

  function exportToCSV(data) {
    const headers = [
      "Type Lead", "Courriel", "Prénom", "Nom",
      "Téléphone", "Nom Entreprise", "Fonction", "Secteur",
      "Décideur", "Nom Décideur",
      "Intérêt Client (1-3)", "Intérêt Pour Nous (1-3)",
      "Notes", "Actions à suivre", "Date de création"
    ];

    // Mapping des noms de champs du formulaire aux en-têtes CSV
    const fieldToHeaderMap = {
      leadType: "Type Lead",
      email: "Courriel",
      prenom: "Prénom",
      nom: "Nom",
      telephone: "Téléphone",
      entreprise: "Nom Entreprise",
      intitule: "Fonction",
      secteur: "Secteur",
      decideur: "Décideur",
      nomDecideur: "Nom Décideur",
      interetClient: "Intérêt Client (1-3)",
      interetII: "Intérêt Pour Nous (1-3)",
      notes: "Notes",
      actions: "Actions à suivre",
      timestamp: "Date de création"
    };

    let csvContent = headers.join(",") + "\n";

    data.forEach(lead => {
      const row = headers.map(header => {
        const fieldName = Object.keys(fieldToHeaderMap).find(key => fieldToHeaderMap[key] === header);
        let value = lead[fieldName] || "";

        // Format date
        if (fieldName === 'timestamp' && value) {
          try {
            value = new Date(value).toLocaleString();
          } catch (e) {
            // Keep original value if date parsing fails
          }
        }

        // Échapper les guillemets doubles et les virgules dans les valeurs
        value = value.toString().replace(/"/g, '""');
        if (value.includes(",") || value.includes("\n")) {
          value = `"${value}"`;
        }
        return value;
      }).join(",");
      csvContent += row + "\n";
    });

    downloadFile(csvContent, 'text/csv;charset=utf-8;', `leads_salon_export_${formatDate(new Date())}.csv`);
    showToast('Succès', `${data.length} fiche(s) exportée(s) !`, 'success');
  }

  function exportToJSON(data) {
    const jsonContent = JSON.stringify(data, null, 2);
    downloadFile(jsonContent, 'application/json', `leads_salon_export_${formatDate(new Date())}.json`);
    showToast('Succès', `${data.length} fiche(s) exportée(s) en JSON !`, 'success');
  }

  importButton.addEventListener('click', () => {
    const file = importFileInput.files[0];
    if (!file) {
      showToast('Erreur', 'Veuillez sélectionner un fichier à importer.', 'error');
      return;
    }

    const reader = new FileReader();
    reader.onload = async function (e) {
      try {
        let importedLeads = [];

        if (file.name.endsWith('.csv')) {
          importedLeads = parseCSV(e.target.result);
        } else if (file.name.endsWith('.json')) {
          importedLeads = JSON.parse(e.target.result);
        } else {
          throw new Error('Format de fichier non supporté');
        }

        if (Array.isArray(importedLeads) && importedLeads.length > 0) {
          // Generate new IDs for imported leads to avoid conflicts
          // and save each to DB
          for (const lead of importedLeads) {
            if (!lead.leadId || leadsData.some(existingLead => existingLead.leadId === lead.leadId)) {
              lead.leadId = generateId();
            }
            if (!lead.timestamp) {
              lead.timestamp = new Date().toISOString();
            }
            // Set completion status
            lead.isComplete = lead.email && lead.email.trim() !== '';
            await saveLeadToDB(lead); // Save each lead to DB
            leadsData.push(lead); // Also update local array for immediate UI update
          }

          showToast('Succès', `${importedLeads.length} fiche(s) importée(s) avec succès !`, 'success');
          importFileInput.value = '';
          importExportModal.classList.add('hidden');
          renderFiches(); // Re-render fiches to show imported ones
        } else {
          throw new Error('Aucune donnée valide trouvée');
        }
      } catch (error) {
        console.error('Import error:', error);
        showToast('Erreur', `Erreur lors de l'importation: ${error.message}`, 'error');
      }
    };

    if (file.name.endsWith('.csv')) {
      reader.readAsText(file);
    } else if (file.name.endsWith('.json')) {
      reader.readAsText(file);
    } else {
      showToast('Erreur', 'Format de fichier non supporté. Utilisez CSV ou JSON.', 'error');
    }
  });

  // Delete lead
  confirmDeleteButton.addEventListener('click', async () => {
    if (!leadToDelete) return;

    try {
      await deleteLeadFromDB(leadToDelete);
      // Remove from leads data
      leadsData = leadsData.filter(lead => lead.leadId !== leadToDelete);

      // Close modal
      confirmDeleteModal.classList.add('hidden');

      // Update fiches display
      renderFiches();

      showToast('Succès', 'Fiche supprimée avec succès !', 'success');
      leadToDelete = null;
    } catch (error) {
      console.error('Failed to delete lead from DB:', error);
      showToast('Erreur', 'La suppression de la fiche a échoué.', 'error');
      // Optionally, restore UI or leadToDelete if needed
    }
  });

  closeDeleteModalButton.addEventListener('click', closeDeleteModal);
  cancelDeleteButton.addEventListener('click', closeDeleteModal);

  function closeDeleteModal() {
    confirmDeleteModal.classList.add('hidden');
    leadToDelete = null;
  }
});
